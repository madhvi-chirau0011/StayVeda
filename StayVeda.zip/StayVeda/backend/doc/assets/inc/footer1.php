<footer class="footer footer-alt">
    2022 - <?php echo date('Y'); ?> &copy; StayVeda Developed By <a href="https://developerrony.com">Harshita Pawar</a></a>

</footer>